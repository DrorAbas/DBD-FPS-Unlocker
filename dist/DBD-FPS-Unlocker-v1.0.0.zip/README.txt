DBD FPS Unlocker v1.0.0

1. Extract every file from the ZIP.
2. Close Dead by Daylight completely.
3. Run Start_DBD_FPS_Unlocker.cmd.

Unofficial fan-made utility.
Created with substantial AI assistance, including OpenAI's ChatGPT.
See the public repository README and AI_DISCLOSURE.md for full details.
